package com.zz.search;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BankSearch {
    public static final String SPLITTER = ",";
    public static final int MAX_COLUMN = 6;
    public static final String DATA_FILE_PATH = "src/main/resources/sample_data.csv";

    private List<String[]> data;

    // constructor
    BankSearch() {
        data = new ArrayList<>();
        try (FileReader fr = new FileReader(DATA_FILE_PATH);
             BufferedReader br = new BufferedReader(fr)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] lineData = line.split(SPLITTER);
                data.add(lineData);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace(); //replace with log.error
        } catch (IOException e) {
            e.printStackTrace(); //replace with log.error
        }
    }

    public List<String[]> searchByColumn(int col, String val) {
        List result = new ArrayList();
        result.add(data.get(0));
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i)[col].equalsIgnoreCase(val.trim())) {
                result.add(data.get(i));
            }
        }
        return result;
    }

    public List<String[]> searchByCombinedColumns(int col1, String val1, int col2, String val2) {
        List result = new ArrayList<>();
        result.add(data.get(0));
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i)[col1].equalsIgnoreCase(val1.trim())
            && data.get(i)[col2].equalsIgnoreCase(val2.trim())) {
                result.add(data.get(i));
            }
        }
        return result;
    }

    public void display(List<String[]> records) {
        for (int i = 0; i < records.size(); i++) {
            String[] row = records.get(i);
            for (int j = 0; j < MAX_COLUMN; j++) {
                System.out.printf("%-20s", row[j].trim());
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("You do not have enough arguments!");
            return;
        }
        BankSearch bankSearch = new BankSearch();
        switch (args[0]) {
            case "name":
                bankSearch.display(bankSearch.searchByColumn(1, args[1]));
                break;
            case "type":
                bankSearch.display(bankSearch.searchByColumn(2, args[1]));
                break;
            case "city":
                bankSearch.display(bankSearch.searchByColumn(3, args[1]));
                break;
            case "state":
                bankSearch.display(bankSearch.searchByColumn(4, args[1]));
                break;
            case "zip":
                bankSearch.display(bankSearch.searchByColumn(5, args[1]));
                break;
            case "city&state":
                if (args.length < 3) {
                    System.out.println("You do not have enough arguments for city and state!");
                    return;
                }
                bankSearch.display(bankSearch.searchByCombinedColumns(3, args[1], 4, args[2]));
                break;
            default:
                System.out.println("Your search criteria is incorrect!");
                break;
        }
    }
}
