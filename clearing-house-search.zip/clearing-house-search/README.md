# This is a bank location searching tool

    Command line usage: 
    
1. Search by single value:

    banksearch [ways] [value]

    ways option: name,type,city,state,zip
    calue option: value of ways selection

2. Search by city and state

    banksearch city&state [city] [state]



Note: 
   For unit testing, we need cover all scenario and error conditions, such as data file not found, too fewer arguments, keyword misspelled, etc